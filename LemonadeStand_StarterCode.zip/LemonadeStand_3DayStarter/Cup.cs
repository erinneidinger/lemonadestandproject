﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LemonadeStand_3DayStarter
{
    class Cup : Item
    {
        // member variables (HAS A)

        // constructor (SPAWNER)
        public Cup()
        {
            name = "cup";
        }

        // member methods (CAN DO)
    }
}
