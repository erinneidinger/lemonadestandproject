﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LemonadeStand_3DayStarter
{
    class IceCube : Item
    {
        // member variables (HAS A)

        // constructor (SPAWNER)
        public IceCube()
        {
            name = "ice cube";
        }

        // member methods (CAN DO)
    }
}
