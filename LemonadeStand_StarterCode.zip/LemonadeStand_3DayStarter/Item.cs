﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LemonadeStand_3DayStarter
{
    abstract class Item
    {
        // member variables (HAS A)
        public string name;

        // constructor (SPAWNER)
        static Item()
        {
            
        }

        // member methods (CAN DO)
    }
}
